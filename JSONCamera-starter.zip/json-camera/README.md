# JSON Camera (starter)

A beginner-friendly Android CameraX starter project. It uses the rear camera, imports a JSON preset, shows a lightweight warm/cool overlay in the live preview, and applies color-matrix processing to captured JPEG photos.

## Important limitations
- The live preview overlay is an approximation, not full-frame real-time color grading. Portable full-frame GPU grading needs a dedicated OpenGL/Vulkan rendering pipeline.
- The captured-photo processing is a basic color matrix. It does not provide AI enhancement, true iPhone processing, RAW processing, advanced denoising, or detail reconstruction.
- This starter has not been device-tested. Build and test before relying on it.

## Build using a computer
Open this folder in Android Studio, let Gradle sync, then choose Build > Build Bundle(s) / APK(s) > Build APK(s).

## Build using only an Android phone (cloud build)
1. Download and extract the ZIP on your phone.
2. Create a GitHub account if needed, then create a new repository named `JSONCamera`.
3. Upload the extracted project files and folders to the repository. Make sure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab, select **Build JSON Camera APK**, and tap **Run workflow**. You can also commit a change to the `main` branch to trigger a build.
5. When the workflow finishes successfully, open its run, scroll to **Artifacts**, and download `JSONCamera-debug-apk`.
6. Extract the artifact ZIP and tap `app-debug.apk` to install it. Android may ask you to allow installs from that browser or file manager.

## JSON format

```json
{
  "preset_name": "Natural Camera",
  "color_grading": {
    "contrast": 1.04,
    "saturation": 0.96,
    "brightness": 0.02,
    "warmth": 0.03
  }
}
```

Accepted ranges are clamped in the app. If the build fails, open the Actions run and read the first Gradle error; Android SDK and dependency versions can change.
