package com.example.jsoncamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.roundToInt

data class CameraPreset(
    val name: String = "Natural",
    val contrast: Float = 1.04f,
    val saturation: Float = 0.96f,
    val brightness: Float = 0.0f,
    val warmth: Float = 0.02f
)

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var liveTint: View
    private lateinit var presetLabel: TextView
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var preset = CameraPreset()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else toast("Camera permission is required.")
        }

    private val jsonPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) importPreset(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        liveTint = findViewById(R.id.liveTint)
        presetLabel = findViewById(R.id.presetLabel)
        cameraExecutor = Executors.newSingleThreadExecutor()

        findViewById<Button>(R.id.captureButton).setOnClickListener { takePhoto() }
        findViewById<Button>(R.id.importButton).setOnClickListener {
            jsonPicker.launch(arrayOf("application/json", "text/*", "application/octet-stream"))
        }
        applyLivePreviewLook()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageCapture
                )
            } catch (e: Exception) {
                toast("Could not start camera: ${e.localizedMessage ?: "unknown error"}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun importPreset(uri: Uri) {
        try {
            val json = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw IllegalArgumentException("Could not read selected file")
            val root = JSONObject(json)
            val grading = root.optJSONObject("color_grading") ?: root
            preset = CameraPreset(
                name = root.optString("preset_name", root.optString("name", "Imported")),
                contrast = grading.optDouble("contrast", 1.04).toFloat().coerceIn(0.5f, 1.8f),
                saturation = grading.optDouble("saturation", 0.96).toFloat().coerceIn(0f, 2f),
                brightness = grading.optDouble("brightness", 0.0).toFloat().coerceIn(-0.5f, 0.5f),
                warmth = grading.optDouble("warmth", 0.02).toFloat().coerceIn(-0.3f, 0.3f)
            )
            presetLabel.text = "Preset: ${preset.name}"
            applyLivePreviewLook()
            toast("Preset imported")
        } catch (e: Exception) {
            toast("Invalid JSON preset: ${e.localizedMessage ?: "check file format"}")
        }
    }

    private fun applyLivePreviewLook() {
        // CameraX PreviewView does not expose a portable full-frame color matrix.
        // This subtle overlay is only a lightweight live approximation.
        val alpha = (preset.warmth.coerceIn(-0.1f, 0.1f).absoluteValue() * 100).roundToInt()
        val color = if (preset.warmth >= 0) Color.rgb(255, 220, 170) else Color.rgb(170, 210, 255)
        liveTint.setBackgroundColor(Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color)))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: run {
            toast("Camera is still starting")
            return
        }
        val name = "JSONCAM_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JSONCamera")
        }
        val output = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()

        capture.takePicture(output, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                val uri = result.savedUri
                if (uri == null) {
                    runOnUiThread { toast("Photo saved, but URI was unavailable") }
                    return
                }
                try {
                    val input = contentResolver.openInputStream(uri)
                    val bitmap = input?.use { BitmapFactory.decodeStream(it) }
                        ?: throw IllegalStateException("Could not read captured image")
                    val processed = applyPreset(bitmap, preset)
                    contentResolver.openOutputStream(uri, "wt")?.use { stream ->
                        processed.compress(Bitmap.CompressFormat.JPEG, 96, stream)
                    } ?: throw IllegalStateException("Could not write processed image")
                    if (processed !== bitmap) processed.recycle()
                    bitmap.recycle()
                    runOnUiThread { toast("Processed photo saved to Pictures/JSONCamera") }
                } catch (e: Exception) {
                    runOnUiThread { toast("Photo captured; processing failed: ${e.localizedMessage}") }
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { toast("Capture failed: ${exception.localizedMessage}") }
            }
        })
    }

    private fun applyPreset(source: Bitmap, p: CameraPreset): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(output)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        val cm = ColorMatrix()
        cm.setSaturation(p.saturation)
        val c = p.contrast
        val b = p.brightness * 255f
        val contrastMatrix = ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, b,
            0f, c, 0f, 0f, b,
            0f, 0f, c, 0f, b,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(contrastMatrix)
        val warmthMatrix = ColorMatrix(floatArrayOf(
            1f + p.warmth, 0f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f, 0f,
            0f, 0f, 1f - p.warmth, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(warmthMatrix)
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}

private fun Float.absoluteValue(): Float = kotlin.math.abs(this)
